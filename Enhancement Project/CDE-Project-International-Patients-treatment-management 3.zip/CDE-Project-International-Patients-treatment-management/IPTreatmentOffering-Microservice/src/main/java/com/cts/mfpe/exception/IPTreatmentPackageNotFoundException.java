package com.cts.mfpe.exception;

@SuppressWarnings("serial")
public class IPTreatmentPackageNotFoundException extends Exception{

	public IPTreatmentPackageNotFoundException(String message) {
		
		super(message);
	}
}
