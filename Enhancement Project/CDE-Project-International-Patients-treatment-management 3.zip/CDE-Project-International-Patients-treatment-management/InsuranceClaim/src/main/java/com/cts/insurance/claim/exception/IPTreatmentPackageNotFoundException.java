package com.cts.insurance.claim.exception;
@SuppressWarnings("serial")
public class IPTreatmentPackageNotFoundException extends Exception{

	public IPTreatmentPackageNotFoundException(String message) {
		
		super(message);
	}
}
