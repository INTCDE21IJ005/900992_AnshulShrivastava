insert into users (id, password, user_name) values (1, '$2a$10$BhBZRNJZKsGHc4K6oC64w.EQWT7mb2DcgBXT0CkJMBxJDLHIfkCkK', 'admin');
insert into users (id, password, user_name) values (2, '$2a$10$8rh5etTl0pTNQC7200wZMuaydnccxjEFP7EAtAzJBgv5Kaa9X6QDO', 'user1');
insert into users (id, password, user_name) values (3, '$2a$10$YnXvrEntVWd89EpHhqubbO8EPfAQrjgnYevbuSaHJ81C0B/vANp9y', 'user2');